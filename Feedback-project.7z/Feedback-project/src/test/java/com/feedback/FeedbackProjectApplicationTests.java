package com.feedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
