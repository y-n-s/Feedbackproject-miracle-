package com.feedback.pojo;

public class LoginPojo {
	private String rollNumber;
	private String name;
	private String year;
	private String semester;
	private String branch;
	private String address;
	private String gender;
	private String phoneNumber;
	private String email;
	private String password;
	
	

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getSemester() {
		return semester;
	}

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

//	public LoginPojo(String rollNumber, String name, String year, String semester, String branch, String address,
//			String gender, String phonenumber, String email, String password) {
//		super();
//		this.rollNumber = rollNumber;
//		this.name = name;
//		this.year = year;
//		this.semester = semester;
//		this.branch = branch;
//		this.address = address;
//		this.gender = gender;
//		this.phoneNumber = phonenumber;
//		this.email = email;
//		this.password = password;
//	}

}
