package com.feedback.pdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackProjectPdfDownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackProjectPdfDownloadApplication.class, args);
	}

}
