package com.feedback.pdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackProjectPdfDownloadApplicationTests {

	@Test
	void contextLoads() {
	}

}
